let navBar = () => {
    return `
        <h3>
            <a href="index.html">Home</a>
        </h3>
        <h3>
            <a href="login.html">Login</a>
        </h3>
        <h3>
            <a href="signup.html">Signup</a>
        </h3>
        // <h3>
        //     <a href="admin.html">Admin Page</a>
        // </h3>
    `
}

// export {navBar};
export default navBar;